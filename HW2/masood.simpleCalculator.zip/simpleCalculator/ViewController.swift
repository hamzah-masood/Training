//
//  ViewController.swift
//  simpleCalculator
//
//  Created by MCS on 8/7/19.
//  Copyright © 2019 MCS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //number on screen
    var numberOnDisplay: Double = 0
    //number after the operand
    var secondNumber:Double = 0
    //when doing the calculations
    var performingMath = false
    //storing the operator
    var operand = 0
    
    @IBOutlet weak var calculatorDisplay: UILabel!
    
    @IBAction func numbers(_ sender: UIButton) {
        
        if performingMath == true{
    
            //if it is true we have to reset display so second number can be added
            //sender.tag is -1 as we adding 1 to it since swift defaults to 0 for all tags
            calculatorDisplay.text = String(sender.tag-1)
            numberOnDisplay = Double(calculatorDisplay.text!)!
            performingMath = false
        }
        else{
            
            calculatorDisplay.text = calculatorDisplay.text! + String(sender.tag-1)
            //force unwrap due to us knowing there is a number there
            //also unwrap whole line as we converted the number into a string
            numberOnDisplay = Double(calculatorDisplay.text!)!
            
        }
        
        
        
        
    }
    
    @IBAction func calculations(_ sender: UIButton) {
        //make sure button pressed is not clear, equals or nill
        
        if calculatorDisplay.text != "" && sender.tag != 11 && sender.tag != 16{
            
            secondNumber = Double(calculatorDisplay.text!)!
        
            
            //multiple
            if sender.tag == 12{
                
                calculatorDisplay.text = "*"
                
            }
            //divide
            else if sender.tag == 13{
                
                calculatorDisplay.text = "/"
                
            }
            //subtract
            else if sender.tag == 14{
                
                calculatorDisplay.text = "-"
                
            }
            //add
            else if sender.tag == 15{
                
                calculatorDisplay.text = "+"
        
            }
            
            operand = sender.tag
            performingMath = true
        }
        else if sender.tag == 16{
            
            //multiply
            if operand == 12{
                
                calculatorDisplay.text = String(secondNumber * numberOnDisplay)
                
            }
            //divide
            else if operand == 13{
                
                calculatorDisplay.text = String(secondNumber / numberOnDisplay)
                
            }
            //subtract
            else if operand == 14{
                
                calculatorDisplay.text = String(secondNumber - numberOnDisplay)
                
            }
            //add
            else if operand == 15{
                
                calculatorDisplay.text = String(secondNumber + numberOnDisplay)
                
            }
            
        }
        //clear
        else if sender.tag == 11{
            
            calculatorDisplay.text = ""
            numberOnDisplay = 0
            secondNumber = 0
            operand = 0
            
            
        }
        
    
    }
    
    
    
        override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

