//
//  Elements.swift
//  firstProject
//
//  Created by MCS on 8/11/19.
//  Copyright © 2019 MCS. All rights reserved.
//

import Foundation

struct Elements {
    
    var switchValue: Bool = false
    var sliderValue: Float = 0
    var myTextFieldValue: String = ""
    var stepperValue: Double = 0
    var controlValue: Int = 0
    
}
